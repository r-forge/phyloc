`summary.caic` <-
function(object, ...){

    summary(object$mod, ...)

}

